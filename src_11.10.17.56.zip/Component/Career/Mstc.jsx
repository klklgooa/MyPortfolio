import '../CSS/Career.css';

const Mstc = () => {
  return (

    <div>
      <h1>MSTC</h1>
      <fieldset>
        <legend>MSTC 개요</legend>
        <ul>
          <li>
            개요
          </li>
          <p class="career_p">(주)엠에스티씨는 현대모비스 연구개발본부의 협력사로서
            자동차 AVN, AUDIO 소프트웨어 검증 및 평가, 개발 지원을 주 사업으로 하고있습니다.
            AVN시스템 소프트웨어의 안정성과 신뢰성 확보를 위한 소프트웨어 검증뿐만 아니라 차종
            개발 소프트웨어 설계를 동시에 수행할 수 있는 우수한 경쟁력을 확보하고 있는 기업입니다.
          </p>
          <li>
            Software
          </li>
          <p class="career_p">차종 개발 소프트웨어 설계와 AVN시스팀 검증/평가를 통해 높은 품질과 완성도 높은 차량 생산에 일조하고
            있습니다. IT 및 소프트웨어 전장 장비 확대로 실시간 네비게이션, 원격 차량 제어 및 관리뿐만 아니라
            미디어 스트리밍의 영역까지 다루고 있습니다.</p>

          <li>Testing</li>
          <p class="career_p">QA Quality Assurance
            개발 과정에서의 QA는 개발 마무리 단계에서 필수로 진행해야 하는 업무입니다. 품질 관리를 통해 이슈 Bug
            예방을 목표로 합니다. 소프트웨어 품질 보증 및 효과적인 SQA 구현을 위해 지속적으로 노력합니다.
            - QA 전략 수립 및 단계별 진행 상황 관리 / 품질 기준 수립- 서비스 기획 단계부터 양산에
            걸친 품질 관리 활동 수행- 자기주도적 경험 기반 검증 수행- 신규 OS 출시, 신규 디바이스
            출시, 정책 변경 등 외부 플랫폼 변경 사항 대응- 이슈 대응 및 관리</p>
        </ul>
      </fieldset>
      <br/><br/>
      <fieldset>
        <legend>인턴십</legend>
        <ul>
          <li>정업검증팀 소속 인트라넷 보안 교육</li>
          <li>내비게이션 Dummy H/U 설치 및 소켓 결합의 이해</li>
          <li>READY MODE, ACC MODE, ON MODE, START MODE 로직 이해</li>
          <li>Top level Test case 검증 방법</li>
          <li>향지에 따른 내비게이션 버전 설정</li>
        </ul>
      </fieldset>
      <br/><br/><br/><br/><br/><br/>
    </div>
  );
};

export default Mstc;