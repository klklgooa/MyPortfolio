import Keyard from "../Project/Keyard";
import Hdiary from "../Project/Hdiary";
import Witty from "../Project/Witty";

const projects = [
  {
    tab: "Keyard",
    content: <Keyard></Keyard>,
  },
  {
    tab: "Hdiary",
    content: <Hdiary></Hdiary>,
  },
  {
    tab: "Witty",
    content: <Witty></Witty>,
  }
];

export default projects;
