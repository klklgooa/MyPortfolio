import Resume from "../Intro/Resume";
import SelfIntro from "../Intro/SelfIntro";
const intros = [
  {
    tab: "이력서",
    content: <Resume></Resume>,
  },
  {
    tab: "자기소개서",
    content: <SelfIntro></SelfIntro>,
  },
];

export default intros;
