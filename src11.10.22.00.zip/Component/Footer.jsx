function Footer() {
    return (
        <footer>
            <i>
                Copyright 2023. 황인찬 all rights reserved.
                <br />
                연락처 : 010-5413-0707
            </i>
        </footer>
    );
}
export default Footer;
