import React from "react";
const NotFound = () => {
    return (
        <div>
            <h3>페이지가 없어요 404 Not Fount</h3>
        </div>
    );
};
export default NotFound;